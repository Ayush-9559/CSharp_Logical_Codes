﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{

    //***************** Question 1 ***************//
    //public delegate void Calculation(int a, int b);
    //class Program
    //{
    //    public static void Addition(int a, int b)
    //    {
    //        int result = a + b;
    //        Console.WriteLine("Addition of a and b is {0}",result);
    //    }
    //    public static void Main(string[] args)
    //    {
    //        Calculation obj = new Calculation(Program.Addition);
    //        obj.Invoke(10, 20);
    //    }
    //}
    //***************** Question 2: Swap Using 3 Variables ***************//
    //class SwapNumbersUsingthreevariable
    //{
    //    public static void Main(string[] args)
    //    {
    //        int a = 10;
    //        int b = 20;

    //        Console.WriteLine("Before Swap: ");
    //        Console.WriteLine("a: " + a);
    //        Console.WriteLine("b: " + b);

    //        int c;
    //        c = a;    // c = 10
    //        a = b; // a = 20;
    //        b = c; // b = 10

    //        Console.WriteLine("After Swap: ");
    //        Console.WriteLine("a: " + a);
    //        Console.WriteLine("b: " + b);
    //    }
    //}
    //***************** Question 3: Swap Without Using 3rd Variables ***************//
    //class Swapwithtwovariable
    //{
    //    public static void Main(String[] args)
    //    {
    //        int a = 2;
    //        int b = 3;

    //        Console.WriteLine("Before Swap Without 3rd Variable: ");
    //        Console.WriteLine("a: " + a);
    //        Console.WriteLine("b: " + b);

    //        a = a + b; // a = 2+3=5
    //        b = a - b; // b = 5-3= 2
    //        a = a - b; // a=  5-2= 3

    //        Console.WriteLine("After Swap Without 3rd Variable: ");
    //        Console.WriteLine("a: " + a);
    //        Console.WriteLine("b: " + b);
    //    }
    //}


    //***************** Question 4: // C# program to illustrate the ArrayList **************//
    //class ArrayListProgram
    //{
    //    public static void Main(String[] args)
    //    {
    //        ArrayList al = new ArrayList();
    //        al.Add("Ayush");
    //        al.Add("Vandana");
    //        al.Add(1055);
    //        al.Add("Mohit");
    //        al.Add("Waseem");

    //        string[] arr = { "Ayush", "Vandana", "Rajan", "Waseem", "Mohit" };

    //            Console.WriteLine(arr[1]);
    //        Console.WriteLine("");


    //        foreach(var names in al)
    //        {
    //            Console.WriteLine(names);
    //        }
    //    }
    //}


    //************ Question 5: 
    //class Sample
    //{
    //    public static void Main(string[] args)
    //    {
    //        int x = 4, b = 2;
    //        x -= b /= x * b;
    //        Console.WriteLine(x + " " + b);
    //        Console.ReadLine();
    //    }
    //}


    //************* Question 6:
    //class maths
    //{
    //    public int fun(int k, int y)
    //    {
    //        return k + y;
    //    }
    //    public int fun1(int t, float z)
    //    {
    //        return (t + (int)z);
    //    }
    //}
    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        maths obj = new maths();
    //        int i;
    //        int b = 90;
    //        int c = 100;
    //        int d = 12;
    //        float l = 14.78f;
    //        i = obj.fun(b, c);
    //        Console.WriteLine(i);
    //        int j = (obj.fun1(d, l));
    //        Console.WriteLine(j);
    //        //Console.ReadLine();


    //        //Question 7:
    //        int a, p, q, x;
    //        a = 90;
    //        p = 15;
    //        q = 3;
    //        x = a - p / 3 + q * 2 - 1;
    //        Console.WriteLine(x);
    //        Console.ReadLine();
    //    }
    //}


    //**************** Question 8: Using A CONST Keyword
    //class ConstkeyProgram
    //{
    //    public const int a1 = 20;
    //    public const string name = "name";

    //    public static void Main(String[] args)
    //    {
    //        Console.WriteLine("The integer is: '" + a1 + "' using CONST Keyword");
    //        Console.WriteLine("The String is: '" + name + "' using CONST Keyword");
    //    }
    //}


    //************** Question 9: Method Overloading ************//
    //public class MethodOverloading
    //{
    //    public int Add(int a, int b)
    //    {
    //        return a + b;
    //    }
    //    public int Add(int a, int b, int c)
    //    {
    //        return a + b + c;
    //    }
    //    public double Add(double a, double b, double c)
    //    {
    //        return a + b + c;
    //    }

    //    public class p1
    //    {
    //        public static void Main()
    //        {
    //            MethodOverloading m1 = new MethodOverloading();
    //            Console.WriteLine("First Method: "+ m1.Add(10, 20));

    //            Console.WriteLine("Third Method: "+ m1.Add(5.5, 4.5, 2.5));

    //            Console.WriteLine("Second Method: "+ m1.Add(10, 20, 40));
    //        }
    //    }
    //}

    //*************** Question 10: Method Overriding ***************//
    //using System;

    //public class baseclass
    //{
    //    public virtual void m1(int a, int b)
    //    {
    //        int result = a + b;
    //        Console.WriteLine("This is the virtual method m1 of Base Class: " + result);
    //    }
    //}
    //public class DerviedClass : baseclass
    //{
    //    public override void m1(int a, int b)
    //    {
    //        int result = a + b;
    //        Console.WriteLine("This is the overridden method m1 of Derived Class: " + result);
    //    }
    //}
    //public class MethodOverriding
    //{
    //    public static void Main(string[] args)
    //    {
    //        DerviedClass mo = new DerviedClass();
    //        //baseclass bc = new baseclass();

    //        mo.m1(10, 20);
    //        //bc.m1(5, 10);
    //    }
    //}


    //**************** Question 11: Single Inheritance
    //public class baseclass1
    //{
    //    public void Addition(int a, int b)
    //    {
    //        int c = a + b;
    //        Console.WriteLine("Addition From Base Class: "+a+"+"+b+"=" +c);
    //    }
    //}
    //public class Derivedclass1 : baseclass1
    //{
    //    public void Subtraction(int a, int b)
    //    {
    //        Console.WriteLine("Subtraction From Derived Class: " +a+"-"+b+"="+(a - b));
    //    }
    //}
    //class Inheritance
    //{
    //    public static void Main(String[] args)
    //    {
    //        Derivedclass1 dc1 = new Derivedclass1();
    //        dc1.Addition(10, 5);
    //        dc1.Subtraction(5, 4);
    //    }
    //}


    //************** Question 12: Multilevel Inheritance
    //public class baseclass
    //{
    //    public void Anime()
    //    {
    //        Console.WriteLine("Base Class\n");
    //        Console.WriteLine("Naruto");
    //        Console.WriteLine("Demon Slayer");
    //        Console.WriteLine("My Dress Up Darling\n");
    //    }
    //}
    //public class derivedclass : baseclass
    //{
    //    public void Character()
    //    {
    //        Console.WriteLine("Derived Class\n");
    //        Console.WriteLine("Hinata");
    //        Console.WriteLine("Nezuko");
    //        Console.WriteLine("Kitagawa\n");
    //    }
    //}
    //public class derivedclass2 : derivedclass 
    //{
    //    public void Villian()
    //    {
    //        Console.WriteLine("Further Derived Class\n");
    //        Console.WriteLine("Akatsuki");
    //        Console.WriteLine("Demons");
    //        Console.WriteLine("Cute Girl");
    //    }
    //}

    //class sample
    //{
    //    public static void Main(string[] args)
    //    {
    //        derivedclass2 dc2 = new derivedclass2();
    //        dc2.Anime();
    //        dc2.Character();
    //        dc2.Villian();
    //    }
    //}



    //******************** Question: Write a C# function to reverse a given string using inbuilt function.
    //public class Program
    //    {
    //        public static string ReverseString(string a)
    //        {
    //            char[] c1 = a.ToCharArray(); //We can also put=> (' .ToArray() ')
    //            Array.Reverse(c1);
    //            return new string(c1);
    //        }
    //        public static void Main(string[] args)
    //        {
    //            string s1 = "VANDANA";
    //            string s2 = ReverseString(s1);
    //            Console.WriteLine(s2);
    //        }
    //    }


    //**************** Question: Reverse a string without in-built function Using For Loop
    //public class ReverseStringProgram
    //{
    //    public static string reversestring(string s)
    //    {
    //        char[] cr = s.ToCharArray();
    //        string r = string.Empty;
    //        for (int i = cr.Length - 1; i >= 0; i--)
    //        {
    //            r += cr[i];
    //        }
    //        return r;
    //    }
    //    public static void Main(string[] args)
    //    {
    //        Console.WriteLine(reversestring("AYUSH"));
    //    }
    //}

    

    //**************** Question: Reverse a string without in-built function Using While Loop
    //public class ReverseStringProgram
    //    {
    //        public static string reversestring(string s)
    //        {
    //            char[] cr = s.ToCharArray();
    //            string r1 = string.Empty;

    //            int length;
    //            length = cr.Length - 1;

    //            while(length > -1)
    //            {
    //                r1 += cr[length];
    //                length--;
    //            }
    //            return r1;
    //        }
    //        public static void Main(string[] args)
    //        {
    //            Console.WriteLine(reversestring("TRU KAIT"));
    //        }
    //    }



    //public class HelloWorld
    //{
    //    public static string reverseString(string input)
    //    {
    //        char[] c1 = input.ToCharArray();
    //        string s1 = string.Empty;

    //        for (int i = c1.Length - 1; i > -1; i--)
    //        {
    //            s1 += c1[i];
    //        }
    //        return s1;
    //    }

    //    public static string reverseString2(string a1)
    //    {
    //        char[] c1 = a1.ToCharArray();
    //        Array.Reverse(c1);
    //        return new string(c1);

    //    }
    //    public static void Main(string[] args)
    //    {
    //        Console.WriteLine(reverseString("udnaV"));
    //        Console.WriteLine(reverseString2("anadnaV\n\n"));
    //    }
    //}

    //************* Question: Reveresing a Array

    //class Demo
    //{
    //    public static void Main(string[] args)
    //    {
    //        int[] arr = { 10, 20, 30, 40, 50 };
    //        Console.WriteLine("Original Array: ");

    //        foreach(int i in arr)
    //        {
    //            Console.WriteLine(i);
    //        }
    //        Array.Reverse(arr);
    //        Console.WriteLine("Reversed Array: ");
    //        foreach(int j in arr)
    //        {
    //            Console.WriteLine(j);
    //        }
    //    }
    //}

    //class ReverseArrayProgram
    //{
    //    public static void Main(string[] args)
    //    {
    //        int[] a1 = { 1, 2, 3, 4, 5, 6 };
    //        for (int i = 0; i < a1.Length; i++)
    //        {
    //            for (int j = i; j>=0; j--)
    //            {
    //                Console.WriteLine(a1[j]);
    //            }
    //           Console.WriteLine();
    //        }
    //         // String is reversing //
    //        string s1 = "Ayush";
    //        for (int p = 0; p < s1.Length; p++)
    //        {
    //            for (int q = p; q>=0;q--)
    //            {
    //                Console.WriteLine(s1[q]);
    //            }
    //            Console.WriteLine();
    //        }
    //    }
    //}

    //using System;

    //namespace HelloWorld
    //{
    //    class Program
    //    {
    //        public static string revstring(string s1)
    //        {
    //            char[] c1 = s1.ToCharArray();
    //            Array.Reverse(c1);
    //            return new string(c1);
    //        }
    //        public static void Main(string[] args)
    //        {
    //            int[] arr = { 1, 2, 3, 4, 5 };
    //            Console.WriteLine("Original Array:");
    //            foreach (int i in arr)
    //            {
    //                Console.WriteLine(i);
    //            }
    //            Console.WriteLine("Reversed Array:");
    //            Array.Reverse(arr);
    //            foreach (int j in arr)
    //            {
    //                Console.WriteLine(j);
    //            }


    //            string a1 = "anadnaV";
    //            string a2 = revstring(a1);
    //            Console.WriteLine("\nReverse a string: " + a2);
    //        }
    //    }
    //}

    //class PassvaluReference
    //{
    //    public static void PassByValue(ref int a)
    //    {
    //        a = a + 10;
    //        Console.WriteLine(a);
    //    }
    //    public static void Main(string[] args)
    //    {
    //        int b = 20;
    //        PassByValue(ref b);
    //        Console.WriteLine(b);
    //    }
    //}
    //class FIBONACCISERIES
    //{
    //    public static void Main(string[] args)
    //    {
    //        int a = 0;
    //        int b = 1;
    //        int c;
    //        Console.WriteLine((a + b) + ",");
    //        for (int i = 1; i <= 10; i++)
    //        {
    //            c = a + b;
    //            Console.WriteLine(c);
    //            a = b;
    //            b = c;
    //        }
    //    }
    //}
    //class Program
    //{
    //    public static void Main(string[] args)
    //    {

    //        int numberoflayer = 6, Space, Number;
    //        Console.WriteLine("Print paramid");
    //        for (int i = 1; i <= numberoflayer; i++) // Total number of layer for pramid  
    //        {
    //            for (Space = 1; Space <= (numberoflayer - i); Space++) // Loop For Space  
    //                Console.Write(" ");
    //            for (Number = 1; Number <= i; Number++) //increase the value  
    //                Console.Write('*');
    //            for (Number = (i - 1); Number >= 1; Number--) //decrease the value  
    //                Console.Write('*');
    //            Console.WriteLine();
    //        }
    //    }
    //
    //}

    //public delegate void Square(int a, int b);
    //public delegate void Triangle(int l, int b);
    //    class SquareProgram
    //{
    //    public static void Square(int a, int b)
    //    {
    //        int result = a * b;
    //        Console.WriteLine("Area of Sqaure: "+result);
    //    }
    //    public static void Triangle(int l, int b)
    //    {
    //        int result = (l * b)/2;
    //        Console.WriteLine("Area of Triangle: " + result);
    //    }
    //    public static void Main(String[] args)
    //    {
    //        Square s1 = new Square(SquareProgram.Square);
    //        s1.Invoke(5, 5);
    //        Triangle t1 = new Triangle(SquareProgram.Triangle);
    //        t1.Invoke(2, 3);
    //    }
    //}
    //class program
    //{
    //    public static void PassByValue(ref int a)
    //    {
    //        a = a + 10;
    //        Console.WriteLine("Addition: " + a);
    //    }

    //    public static void Main(string[] args)
    //    {
    //        int a1 = 40;
    //        PassByValue(ref a1);
    //        Console.WriteLine(a1);
    //    }

    //}
}
